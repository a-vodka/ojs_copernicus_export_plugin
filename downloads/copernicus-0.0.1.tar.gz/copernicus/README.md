# ojs to Copernicus export plugin
This plug-in allows to export article meta-data to Copernicus citation index in xml format with respect to official xml-schema

#Installation

1. Dowload latest [archive](/downloads/copernicus-0.0.1.tar.gz)
2. Open OJS > User Home > Journal Management > Plugin Management > Install A New Plugin
3. Choose downloaded file
4. Enjoy if it were works

#Troubleshooting

1. If some gone wrong, please find folder "copernicus" in OJS_ROOT/plugins/importexport/ and delete it
